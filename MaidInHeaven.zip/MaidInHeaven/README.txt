
※メイドインヘブン サンプルプロジェクト
-----------------------------------------------------------------------------------

●対応バージョン
RPGツクールMV ｖ1.6.3

*(1)このサンプルプロジェクトを動かすために以下のプラグインが必要

YEP_CoreEngine
YEP_Battle Engine Core　　
YEP_X_ActSeqPack1
YEP_X_ActSeqPack2
YEP_SkillCore　　　　　　   https://yanflyengineplugins.itch.io/free-starter-pack-essentials　　
YEP_BuffsStatesCore
YEP_X_SkillCooldowns
YEP_ScriptCallPluginCmd

MoviePicture　　　　        https://plugin.fungamemake.com/archives/1006
Trb_BattlerOperation　　　  https://plugin.fungamemake.com/archives/11505
FilterController         　 https://plugin.fungamemake.com/archives/13553
SlowMotion              　  https://plugin.fungamemake.com/archives/13612
SAN_ResidualSprites　　     https://plugin.fungamemake.com/archives/1607
MadeInHeaven　              https://github.com/garyu01/plagin/blob/master/MadeInHeaven
NRP_BattleParallelCommon    https://plugin.fungamemake.com/archives/27882
PicturePriorityCustomize    https://plugin.fungamemake.com/archives/1117
DTextPicture　　　　　　　  https://plugin.fungamemake.com/archives/1037
TraitAnimation              https://plugin.fungamemake.com/archives/28949
SRD_BattleBackScroll　　　  https://plugin.fungamemake.com/archives/26494
RX_T_Change_BattleBackEX    https://w.atwiki.jp/type74rx-t/pages/259.html
MPI_AnimationOverPictures   https://plugin.fungamemake.com/archives/13123
-----------------------------------------------------------------------------------

●利用規約


1.
・RPGツクールMVの正規ユーザーであること。
・同梱されている各種データの配布禁止
・MadeInHeaven.jsは個人で改変可能
・MadeInHeaven.jsについて発生したいかなるバグも制作者は責任を負わない。
・MadeInHeaven.js作者のクレジットなんて必要なし
・サンプルプロジェクト内のデータベース内のカスタムコードは自由に使用OK

-----------------------------------------------------------------------------------
●利用方法

1.上に挙げた*(1)の各プラグインを、プラグイン作者様サイトにてダウンロードし、
本サンプルプロジェクトの「plugins」フォルダにコピーしてください。

-----------------------------------------------------------------------------------
